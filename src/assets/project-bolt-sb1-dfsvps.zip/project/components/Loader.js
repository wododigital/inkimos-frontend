'use client'

import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'

export default function Loader() {
  const loaderRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline()
      
      tl.to('.loader-text', {
        y: 0,
        duration: 1,
        ease: 'power4.out',
        stagger: 0.2
      })
      .to('.loader', {
        y: '-100%',
        duration: 1,
        ease: 'power4.inOut',
        delay: 0.5
      })
    }, loaderRef)

    return () => ctx.revert()
  }, [])

  return (
    <div ref={loaderRef} className="loader fixed inset-0 bg-black z-50 flex items-center justify-center">
      <div className="overflow-hidden">
        <div className="loader-text translate-y-full text-4xl md:text-6xl font-bold text-white font-space">
          Welcome
        </div>
      </div>
    </div>
  )
}