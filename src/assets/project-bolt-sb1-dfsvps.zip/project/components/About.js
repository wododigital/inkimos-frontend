'use client'

import { useRef } from 'react'
import { Code2, Database, Globe, Laptop } from 'lucide-react'

const skills = [
  {
    title: 'Frontend Development',
    icon: <Laptop className="w-8 h-8" />,
    description: 'React, Next.js, TypeScript, Tailwind CSS',
  },
  {
    title: 'Backend Development',
    icon: <Database className="w-8 h-8" />,
    description: 'Node.js, Express, Python, PostgreSQL',
  },
  {
    title: 'Full Stack Development',
    icon: <Code2 className="w-8 h-8" />,
    description: 'RESTful APIs, GraphQL, Docker, AWS',
  },
  {
    title: 'Web Technologies',
    icon: <Globe className="w-8 h-8" />,
    description: 'HTML5, CSS3, JavaScript, Git',
  },
]

export default function About() {
  const aboutRef = useRef(null)

  return (
    <section id="about" className="py-20 bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl md:text-5xl font-bold mb-8 font-space animate-text">About Me</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="fade-in">
            <p className="text-lg text-gray-300 leading-relaxed">
              I'm a passionate Full Stack Developer with a love for creating beautiful, functional, and user-friendly websites and applications. With expertise in both frontend and backend technologies, I bring ideas to life through clean code and innovative solutions.
            </p>
            <p className="text-lg text-gray-300 leading-relaxed mt-4">
              My journey in web development has equipped me with a strong foundation in modern technologies and best practices, allowing me to build scalable and maintainable applications.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {skills.map((skill, index) => (
              <div
                key={index}
                className="fade-in bg-white/5 p-6 rounded-lg backdrop-blur-sm hover:bg-white/10 transition-colors"
              >
                <div className="text-primary mb-4">{skill.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{skill.title}</h3>
                <p className="text-gray-400">{skill.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}