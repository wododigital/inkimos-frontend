'use client'

import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ArrowDownCircle } from 'lucide-react'

export default function Hero() {
  const heroRef = useRef(null)

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.hero-title .word', {
        y: 100,
        opacity: 0,
        duration: 1.5,
        ease: 'power4.out',
        stagger: 0.2,
        delay: 2
      })
    }, heroRef)

    return () => ctx.revert()
  }, [])

  return (
    <section ref={heroRef} className="h-screen flex items-center justify-center relative bg-black text-white px-4">
      <div className="max-w-7xl mx-auto text-center">
        <h1 className="hero-title text-5xl md:text-7xl lg:text-9xl font-bold mb-8 font-space">
          <div className="word">Full Stack</div>
          <div className="word">Developer</div>
        </h1>
        <p className="text-lg md:text-xl opacity-80 mb-12 max-w-2xl mx-auto">
          Crafting digital experiences through elegant code and innovative solutions
        </p>
        <ArrowDownCircle className="animate-bounce w-12 h-12 mx-auto opacity-50" />
      </div>
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent"></div>
    </section>
  )
}