'use client'

import { useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import SplitType from 'split-type'
import Hero from '@/components/Hero'
import About from '@/components/About'
import Projects from '@/components/Projects'
import Contact from '@/components/Contact'
import Navbar from '@/components/Navbar'
import Loader from '@/components/Loader'

export default function Home() {
  const mainRef = useRef(null)

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger)
    
    const ctx = gsap.context(() => {
      // Split text animation
      const texts = document.querySelectorAll('.animate-text')
      texts.forEach(text => {
        const splitText = new SplitType(text, { types: 'chars' })
        gsap.from(splitText.chars, {
          scrollTrigger: {
            trigger: text,
            start: 'top 80%',
            end: 'top 20%',
            scrub: 1,
            markers: false
          },
          opacity: 0.2,
          stagger: 0.1,
          y: 100
        })
      })

      // Fade in animations
      gsap.utils.toArray('.fade-in').forEach(elem => {
        gsap.from(elem, {
          scrollTrigger: {
            trigger: elem,
            start: 'top 80%',
            end: 'top 20%',
            scrub: 1,
            markers: false
          },
          y: 100,
          opacity: 0
        })
      })
    }, mainRef)

    return () => ctx.revert()
  }, [])

  return (
    <main ref={mainRef} className="relative">
      <Loader />
      <Navbar />
      <Hero />
      <About />
      <Projects />
      <Contact />
    </main>
  )
}